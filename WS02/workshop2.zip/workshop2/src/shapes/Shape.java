package shapes;

public interface Shape {
	double perimeter();
}
